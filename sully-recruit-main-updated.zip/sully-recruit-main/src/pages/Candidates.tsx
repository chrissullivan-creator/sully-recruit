import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/layout/PageHeader';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent } from '@/components/ui/card';
import { CandidatePipeline } from '@/components/pipeline/CandidatePipeline';
import { EnrollInSequenceDialog } from '@/components/candidates/EnrollInSequenceDialog';
import { CsvImportDialog } from '@/components/CsvImportDialog';
import { AddCandidateDialog } from '@/components/candidates/AddCandidateDialog';
import { ResumeSearchDialog } from '@/components/candidates/ResumeSearchDialog';
import { useCandidates } from '@/hooks/useSupabaseData';
import { Plus, LayoutGrid, List, Search, Building, Play, ArrowUpDown, ArrowUp, ArrowDown, Upload, FileSearch, FileUp, MapPin, Mail, Users, UserCheck, UserX, Briefcase, Clock3 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ResumeDropZone } from '@/components/shared/ResumeDropZone';
import { formatDistanceToNow } from 'date-fns';

type SortField = 'name' | 'title' | 'company' | 'status' | 'created' | 'updated';
type SortDir = 'asc' | 'desc';

const statusFilters = ['all', 'active', 'inactive', 'placed', 'do_not_contact'] as const;
const statusColors: Record<string, string> = {
  active: 'bg-success/10 text-success border-success/20',
  inactive: 'bg-muted text-muted-foreground border-border',
  placed: 'bg-info/10 text-info border-info/20',
  do_not_contact: 'bg-destructive/10 text-destructive border-destructive/20',
};

const statCards = [
  { key: 'all', label: 'Total', icon: Users },
  { key: 'active', label: 'Active', icon: UserCheck },
  { key: 'inactive', label: 'Inactive', icon: UserX },
  { key: 'placed', label: 'Placed', icon: Briefcase },
] as const;

const Candidates = () => {
  const navigate = useNavigate();
  const [view, setView] = useState<'pipeline' | 'list'>('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortField, setSortField] = useState<SortField>('updated');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [importOpen, setImportOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const { data: candidates = [], isLoading } = useCandidates();
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [enrollOpen, setEnrollOpen] = useState(false);
  const [resumeSearchOpen, setResumeSearchOpen] = useState(false);
  const [resumeDropOpen, setResumeDropOpen] = useState(false);

  const counts = useMemo(() => ({
    all: candidates.length,
    active: candidates.filter((c) => c.status === 'active').length,
    inactive: candidates.filter((c) => c.status === 'inactive').length,
    placed: candidates.filter((c) => c.status === 'placed').length,
  }), [candidates]);

  const filteredCandidates = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    let list = candidates.filter((c) => {
      const haystack = [
        c.full_name,
        c.first_name,
        c.last_name,
        c.current_company,
        c.current_title,
        c.email,
        c.phone,
        c.location,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();

      const matchesSearch = !query || haystack.includes(query);
      const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
      return matchesSearch && matchesStatus;
    });

    list.sort((a, b) => {
      let aVal = '', bVal = '';
      switch (sortField) {
        case 'name': aVal = a.full_name ?? ''; bVal = b.full_name ?? ''; break;
        case 'title': aVal = a.current_title ?? ''; bVal = b.current_title ?? ''; break;
        case 'company': aVal = a.current_company ?? ''; bVal = b.current_company ?? ''; break;
        case 'status': aVal = a.status ?? ''; bVal = b.status ?? ''; break;
        case 'created': aVal = a.created_at ?? ''; bVal = b.created_at ?? ''; break;
        case 'updated': aVal = a.updated_at ?? ''; bVal = b.updated_at ?? ''; break;
      }
      const cmp = aVal.localeCompare(bVal);
      return sortDir === 'asc' ? cmp : -cmp;
    });

    return list;
  }, [candidates, searchQuery, statusFilter, sortField, sortDir]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir((d) => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir(field === 'created' || field === 'updated' ? 'desc' : 'asc');
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ArrowUpDown className="h-3 w-3 opacity-40" />;
    return sortDir === 'asc' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />;
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
  };

  const toggleAll = () => {
    if (selectedIds.length === filteredCandidates.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredCandidates.map((c) => c.id));
    }
  };

  const selectedNames = candidates
    .filter((c) => selectedIds.includes(c.id))
    .map((c) => c.full_name ?? `${c.first_name ?? ''} ${c.last_name ?? ''}`.trim());

  return (
    <MainLayout>
      <PageHeader
        title="Candidates"
        description="Track candidates, search resumes, and move people into sequences without the usual spreadsheet archaeology."
        actions={
          <div className="flex items-center gap-2">
            <div className="flex items-center border border-border rounded-lg overflow-hidden">
              <button
                onClick={() => setView('pipeline')}
                className={cn('p-2 transition-colors', view === 'pipeline' ? 'bg-secondary text-foreground' : 'text-muted-foreground hover:text-foreground')}
              >
                <LayoutGrid className="h-4 w-4" />
              </button>
              <button
                onClick={() => setView('list')}
                className={cn('p-2 transition-colors', view === 'list' ? 'bg-secondary text-foreground' : 'text-muted-foreground hover:text-foreground')}
              >
                <List className="h-4 w-4" />
              </button>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setResumeSearchOpen(true)}>
              <FileSearch className="h-4 w-4 mr-1" />
              Ask Joe
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setResumeDropOpen(true)}>
              <FileUp className="h-4 w-4 mr-1" />
              Resume Drop
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setImportOpen(true)}>
              <Upload className="h-4 w-4 mr-1" />
              Import CSV
            </Button>
            <Button variant="gold" onClick={() => setAddOpen(true)}>
              <Plus className="h-4 w-4" />
              Add Candidate
            </Button>
          </div>
        }
      />

      <div className="p-8 space-y-6">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {statCards.map(({ key, label, icon: Icon }) => (
            <Card key={key} className={cn('border-border cursor-pointer transition-colors hover:border-accent/40', statusFilter === key && 'ring-1 ring-accent/50 border-accent/60')} onClick={() => setStatusFilter(key)}>
              <CardContent className="p-5 flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{label}</p>
                  <p className="text-2xl font-semibold text-foreground">{counts[key]}</p>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/10 text-accent">
                  <Icon className="h-4 w-4" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[260px] max-w-xl">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search name, title, company, email, phone, or location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full h-10 pl-10 pr-4 rounded-lg border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {statusFilters.map((s) => (
              <Button key={s} variant={statusFilter === s ? 'secondary' : 'ghost'} size="sm" onClick={() => setStatusFilter(s)} className="capitalize text-xs">
                {s === 'all' ? 'All' : s.replace('_', ' ')}
              </Button>
            ))}
          </div>

          {selectedIds.length > 0 && (
            <Button variant="gold" size="sm" onClick={() => setEnrollOpen(true)}>
              <Play className="h-3.5 w-3.5" />
              Enroll {selectedIds.length}
            </Button>
          )}
        </div>

        {isLoading ? (
          <p className="text-muted-foreground text-sm">Loading candidates...</p>
        ) : view === 'pipeline' ? (
          <CandidatePipeline />
        ) : (
          <div className="rounded-lg border border-border overflow-hidden bg-card">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-secondary/40">
              <div className="text-sm text-muted-foreground">
                Showing <span className="font-medium text-foreground">{filteredCandidates.length}</span> of {candidates.length} candidates
              </div>
              <div className="text-xs text-muted-foreground flex items-center gap-1">
                <Clock3 className="h-3.5 w-3.5" />
                Sorted by {sortField}
              </div>
            </div>
            <table className="w-full">
              <thead className="bg-secondary">
                <tr>
                  <th className="w-10 px-4 py-3">
                    <Checkbox
                      checked={selectedIds.length === filteredCandidates.length && filteredCandidates.length > 0}
                      onCheckedChange={toggleAll}
                    />
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide cursor-pointer select-none" onClick={() => toggleSort('name')}>
                    <span className="flex items-center gap-1">Name <SortIcon field="name" /></span>
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide cursor-pointer select-none" onClick={() => toggleSort('title')}>
                    <span className="flex items-center gap-1">Title <SortIcon field="title" /></span>
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide cursor-pointer select-none" onClick={() => toggleSort('company')}>
                    <span className="flex items-center gap-1">Company <SortIcon field="company" /></span>
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide cursor-pointer select-none" onClick={() => toggleSort('status')}>
                    <span className="flex items-center gap-1">Status <SortIcon field="status" /></span>
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide">Contact</th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide cursor-pointer select-none" onClick={() => toggleSort('updated')}>
                    <span className="flex items-center gap-1">Updated <SortIcon field="updated" /></span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredCandidates.map((candidate) => {
                  const fullName = candidate.full_name ?? `${candidate.first_name ?? ''} ${candidate.last_name ?? ''}`.trim() || 'Unknown';
                  return (
                    <tr key={candidate.id} className="hover:bg-muted/50 transition-colors cursor-pointer">
                      <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                        <Checkbox checked={selectedIds.includes(candidate.id)} onCheckedChange={() => toggleSelect(candidate.id)} />
                      </td>
                      <td className="px-4 py-3" onClick={() => navigate(`/candidates/${candidate.id}`)}>
                        <div className="flex items-center gap-3">
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent/10 text-xs font-medium text-accent">
                            {(candidate.first_name?.[0] ?? '')}{(candidate.last_name?.[0] ?? '')}
                          </div>
                          <div>
                            <div className="text-sm font-medium text-foreground">{fullName}</div>
                            <div className="text-xs text-muted-foreground flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {candidate.location ?? 'Location not set'}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground" onClick={() => navigate(`/candidates/${candidate.id}`)}>{candidate.current_title ?? '-'}</td>
                      <td className="px-4 py-3" onClick={() => navigate(`/candidates/${candidate.id}`)}>
                        <span className="text-sm text-muted-foreground flex items-center gap-1">
                          <Building className="h-3 w-3" />
                          {candidate.current_company ?? '-'}
                        </span>
                      </td>
                      <td className="px-4 py-3" onClick={() => navigate(`/candidates/${candidate.id}`)}>
                        <span className={cn('stage-badge border', statusColors[candidate.status] ?? 'bg-info/10 text-info border-info/20')}>
                          {candidate.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground" onClick={() => navigate(`/candidates/${candidate.id}`)}>
                        <div className="space-y-1">
                          <div className="flex items-center gap-1 truncate"><Mail className="h-3 w-3" /> {candidate.email ?? '-'}</div>
                          <div className="text-xs">{candidate.phone ?? 'No phone'}</div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground" onClick={() => navigate(`/candidates/${candidate.id}`)}>
                        {candidate.updated_at ? formatDistanceToNow(new Date(candidate.updated_at), { addSuffix: true }) : '-'}
                      </td>
                    </tr>
                  );
                })}
                {filteredCandidates.length === 0 && (
                  <tr><td colSpan={7} className="px-4 py-10 text-center text-sm text-muted-foreground">No candidates match your filters. Human data hygiene strikes again.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <EnrollInSequenceDialog open={enrollOpen} onOpenChange={setEnrollOpen} candidateIds={selectedIds} candidateNames={selectedNames} />
      <CsvImportDialog open={importOpen} onOpenChange={setImportOpen} entityType="candidates" />
      <AddCandidateDialog open={addOpen} onOpenChange={setAddOpen} />
      <ResumeSearchDialog open={resumeSearchOpen} onOpenChange={setResumeSearchOpen} />
      <ResumeDropZone entityType="candidate" open={resumeDropOpen} onOpenChange={setResumeDropOpen} />
    </MainLayout>
  );
};

export default Candidates;
