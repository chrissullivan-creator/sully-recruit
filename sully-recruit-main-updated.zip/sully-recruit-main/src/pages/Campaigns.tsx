import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/layout/PageHeader';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent } from '@/components/ui/card';
import { useSequences } from '@/hooks/useSupabaseData';
import { Plus, Search, Play, Pause, Mail, MessageSquare, Phone, Linkedin, BarChart3, Loader2, Trash2, X, Users, Clock3, Activity, PauseCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { formatDistanceToNow, isPast } from 'date-fns';

const statusColors: Record<string, string> = {
  draft: 'bg-muted text-muted-foreground border-border',
  active: 'bg-success/10 text-success border-success/20',
  paused: 'bg-warning/10 text-warning border-warning/20',
  completed: 'bg-info/10 text-info border-info/20',
};

const channelIcons: Record<string, React.ReactNode> = {
  linkedin: <Linkedin className="h-3.5 w-3.5" />,
  linkedin_message: <Linkedin className="h-3.5 w-3.5" />,
  linkedin_connection: <Linkedin className="h-3.5 w-3.5" />,
  linkedin_recruiter: <Linkedin className="h-3.5 w-3.5" />,
  email: <Mail className="h-3.5 w-3.5" />,
  sms: <MessageSquare className="h-3.5 w-3.5" />,
  phone: <Phone className="h-3.5 w-3.5" />,
};

const Campaigns = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<string>('all');
  const [creating, setCreating] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [bulkLoading, setBulkLoading] = useState(false);
  const { data: sequences = [], isLoading } = useSequences();
  const queryClient = useQueryClient();

  const filteredSequences = useMemo(() => sequences.filter((seq: any) => {
    const haystack = [seq.name, seq.description, seq.channel, seq.jobs?.title, seq.jobs?.company_name].filter(Boolean).join(' ').toLowerCase();
    const matchesSearch = haystack.includes(searchQuery.toLowerCase());
    const matchesFilter = filter === 'all' || seq.status === filter;
    return matchesSearch && matchesFilter;
  }), [sequences, searchQuery, filter]);

  const summary = useMemo(() => {
    const totalEnrollments = sequences.reduce((sum: number, seq: any) => sum + ((seq.sequence_enrollments as any[])?.length ?? 0), 0);
    const active = sequences.filter((seq: any) => seq.status === 'active').length;
    const paused = sequences.filter((seq: any) => seq.status === 'paused').length;
    const dueNow = sequences.reduce((sum: number, seq: any) => {
      const due = ((seq.sequence_enrollments as any[]) ?? []).filter((enrollment: any) => enrollment.status === 'active' && enrollment.next_step_at && isPast(new Date(enrollment.next_step_at))).length;
      return sum + due;
    }, 0);
    return { total: sequences.length, active, paused, totalEnrollments, dueNow };
  }, [sequences]);

  const allSelected = filteredSequences.length > 0 && filteredSequences.every((s: any) => selected.has(s.id));

  const toggleSelect = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (allSelected) setSelected(new Set());
    else setSelected(new Set(filteredSequences.map((s: any) => s.id)));
  };

  const clearSelection = () => setSelected(new Set());

  const handleCardClick = (seqId: string) => {
    if (selected.size > 0) {
      toggleSelect(seqId);
      return;
    }
    navigate(`/campaigns/${seqId}`);
  };

  const handleCreateNew = async () => {
    setCreating(true);
    try {
      const userId = (await supabase.auth.getUser()).data.user?.id;
      const { data: seq, error } = await supabase
        .from('sequences')
        .insert({ name: 'Untitled Sequence', channel: 'email', status: 'draft', stop_on_reply: true, created_by: userId } as any)
        .select('id')
        .single();
      if (error) throw error;
      queryClient.invalidateQueries({ queryKey: ['sequences'] });
      navigate(`/campaigns/${seq.id}`);
    } catch (err: any) {
      toast.error(err.message || 'Failed to create sequence');
    } finally {
      setCreating(false);
    }
  };

  const toggleStatus = async (e: React.MouseEvent, seqId: string, currentStatus: string) => {
    e.stopPropagation();
    const newStatus = currentStatus === 'active' ? 'paused' : 'active';
    try {
      const { error } = await supabase.from('sequences').update({ status: newStatus } as any).eq('id', seqId);
      if (error) throw error;
      queryClient.invalidateQueries({ queryKey: ['sequences'] });
      toast.success(`Sequence ${newStatus === 'active' ? 'activated' : 'paused'}`);
    } catch (err: any) {
      toast.error(err.message || 'Failed to update status');
    }
  };

  const bulkAction = async (action: 'activate' | 'pause' | 'delete') => {
    if (selected.size === 0) return;
    setBulkLoading(true);
    const ids = Array.from(selected);
    try {
      if (action === 'delete') {
        await supabase.from('sequence_steps').delete().in('sequence_id', ids);
        await supabase.from('sequence_enrollments').delete().in('sequence_id', ids);
        const { error } = await supabase.from('sequences').delete().in('id', ids);
        if (error) throw error;
        toast.success(`Deleted ${ids.length} sequence${ids.length > 1 ? 's' : ''}`);
      } else {
        const newStatus = action === 'activate' ? 'active' : 'paused';
        const { error } = await supabase.from('sequences').update({ status: newStatus } as any).in('id', ids);
        if (error) throw error;
        toast.success(`${action === 'activate' ? 'Activated' : 'Paused'} ${ids.length} sequence${ids.length > 1 ? 's' : ''}`);
      }
      queryClient.invalidateQueries({ queryKey: ['sequences'] });
      setSelected(new Set());
    } catch (err: any) {
      toast.error(err.message || `Failed to ${action} sequences`);
    } finally {
      setBulkLoading(false);
    }
  };

  return (
    <MainLayout>
      <PageHeader
        title="Sequences"
        description="Multi-channel outreach with enough visibility to know what is actually running, which is apparently a luxury."
        actions={
          <Button variant="gold" onClick={handleCreateNew} disabled={creating}>
            {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />} New Sequence
          </Button>
        }
      />

      <div className="p-8 space-y-6">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {[
            { label: 'Total Sequences', value: summary.total, icon: Activity },
            { label: 'Active', value: summary.active, icon: Play },
            { label: 'Paused', value: summary.paused, icon: PauseCircle },
            { label: 'Due Now', value: summary.dueNow, icon: Clock3 },
          ].map(({ label, value, icon: Icon }) => (
            <Card key={label}><CardContent className="p-5 flex items-center justify-between"><div><p className="text-sm text-muted-foreground">{label}</p><p className="text-2xl font-semibold">{value}</p></div><div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/10 text-accent"><Icon className="h-4 w-4" /></div></CardContent></Card>
          ))}
        </div>

        {selected.size > 0 && (
          <div className="flex items-center gap-3 rounded-lg border border-accent/50 bg-accent/5 px-4 py-3 animate-in fade-in slide-in-from-top-2 duration-200">
            <Checkbox checked={allSelected} onCheckedChange={toggleSelectAll} />
            <span className="text-sm font-medium text-foreground">{selected.size} selected</span>
            <div className="h-4 w-px bg-border" />
            <Button variant="ghost" size="sm" onClick={() => bulkAction('activate')} disabled={bulkLoading}><Play className="h-3.5 w-3.5 text-success mr-1" /> Activate</Button>
            <Button variant="ghost" size="sm" onClick={() => bulkAction('pause')} disabled={bulkLoading}><Pause className="h-3.5 w-3.5 text-warning mr-1" /> Pause</Button>
            <Button variant="ghost" size="sm" onClick={() => bulkAction('delete')} disabled={bulkLoading} className="text-destructive hover:text-destructive"><Trash2 className="h-3.5 w-3.5 mr-1" /> Delete</Button>
            {bulkLoading && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />}
            <Button variant="ghost" size="icon" className="ml-auto h-7 w-7" onClick={clearSelection}><X className="h-3.5 w-3.5" /></Button>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[260px] max-w-xl">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input type="text" placeholder="Search sequence, job, channel, or description..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full h-10 pl-10 pr-4 rounded-lg border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <Button variant={filter === 'all' ? 'secondary' : 'ghost'} size="sm" onClick={() => setFilter('all')}>All</Button>
            <Button variant={filter === 'active' ? 'secondary' : 'ghost'} size="sm" onClick={() => setFilter('active')}>Active</Button>
            <Button variant={filter === 'paused' ? 'secondary' : 'ghost'} size="sm" onClick={() => setFilter('paused')}>Paused</Button>
            <Button variant={filter === 'draft' ? 'secondary' : 'ghost'} size="sm" onClick={() => setFilter('draft')}>Drafts</Button>
            <Button variant={filter === 'completed' ? 'secondary' : 'ghost'} size="sm" onClick={() => setFilter('completed')}>Completed</Button>
          </div>
        </div>

        {isLoading ? (
          <p className="text-muted-foreground text-sm">Loading sequences...</p>
        ) : filteredSequences.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <p className="text-muted-foreground mb-2">No sequences found</p>
            <p className="text-sm text-muted-foreground mb-4">Create your first outreach sequence to get started.</p>
            <Button variant="gold" onClick={handleCreateNew} disabled={creating}>{creating ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Plus className="h-4 w-4 mr-1" />} New Sequence</Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredSequences.map((seq: any) => {
              const steps = ((seq.sequence_steps as any[]) ?? []).slice().sort((a: any, b: any) => a.step_order - b.step_order);
              const enrollments = (seq.sequence_enrollments as any[]) ?? [];
              const activeEnrollments = enrollments.filter((e: any) => e.status === 'active').length;
              const dueNow = enrollments.filter((e: any) => e.status === 'active' && e.next_step_at && isPast(new Date(e.next_step_at))).length;
              const isSelected = selected.has(seq.id);

              return (
                <div key={seq.id} onClick={() => handleCardClick(seq.id)} className={cn('rounded-lg border bg-card p-5 transition-all duration-150 cursor-pointer hover-lift group relative', isSelected ? 'border-accent ring-1 ring-accent/50' : 'border-border hover:border-accent/50')}>
                  <div className={cn('absolute top-3 left-3 transition-opacity', selected.size > 0 || isSelected ? 'opacity-100' : 'opacity-0 group-hover:opacity-100')} onClick={(e) => e.stopPropagation()}>
                    <Checkbox checked={isSelected} onCheckedChange={() => toggleSelect(seq.id)} />
                  </div>

                  <div className={cn('flex items-start justify-between mb-4', selected.size > 0 || isSelected ? 'pl-8' : 'group-hover:pl-8 transition-all')}>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-base font-semibold text-foreground truncate">{seq.name}</h3>
                        {seq.stop_on_reply && <span className="text-[11px] rounded-full border border-border px-2 py-0.5 text-muted-foreground">Stops on reply</span>}
                      </div>
                      <div className="mt-1 text-xs text-muted-foreground flex flex-wrap items-center gap-1.5">
                        <span className="capitalize">{seq.channel}</span>
                        {seq.description && <><span>•</span><span className="truncate max-w-[280px]">{seq.description}</span></>}
                        {seq.jobs?.title && <><span>•</span><span className="text-gold font-medium">{seq.jobs.title}</span></>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0 ml-3">
                      {(seq.status === 'active' || seq.status === 'paused') && (
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={(e) => toggleStatus(e, seq.id, seq.status)}>
                          {seq.status === 'active' ? <Pause className="h-3.5 w-3.5 text-warning" /> : <Play className="h-3.5 w-3.5 text-success" />}
                        </Button>
                      )}
                      <span className={cn('stage-badge border capitalize', statusColors[seq.status] ?? '')}>{seq.status}</span>
                    </div>
                  </div>

                  <div className={cn('flex items-center gap-1 mb-4', selected.size > 0 || isSelected ? 'pl-8' : 'group-hover:pl-8 transition-all')}>
                    {steps.length > 0 ? steps.map((step: any, index: number) => (
                      <div key={step.id} className="flex items-center">
                        <div className="flex h-7 w-7 items-center justify-center rounded-full bg-muted text-muted-foreground">{channelIcons[step.channel ?? seq.channel] ?? <Mail className="h-3.5 w-3.5" />}</div>
                        {index < steps.length - 1 && <div className="h-px w-6 bg-border" />}
                      </div>
                    )) : <span className="text-xs text-muted-foreground">No steps yet</span>}
                    {steps.length > 0 && <span className="ml-2 text-xs text-muted-foreground">{steps.length} steps</span>}
                  </div>

                  <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border">
                    <div>
                      <p className="text-lg font-semibold text-foreground flex items-center gap-1"><Users className="h-4 w-4 text-muted-foreground" /> {enrollments.length}</p>
                      <p className="text-xs text-muted-foreground">Enrolled</p>
                    </div>
                    <div>
                      <p className="text-lg font-semibold text-foreground">{activeEnrollments}</p>
                      <p className="text-xs text-muted-foreground">Active</p>
                    </div>
                    <div>
                      <p className={cn('text-lg font-semibold', dueNow > 0 ? 'text-warning' : 'text-foreground')}>{dueNow}</p>
                      <p className="text-xs text-muted-foreground">Due now</p>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
                    <span>Updated {formatDistanceToNow(new Date(seq.updated_at), { addSuffix: true })}</span>
                    <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); navigate(`/campaigns/${seq.id}`); }}>
                      <BarChart3 className="h-4 w-4 mr-1" /> Open
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default Campaigns;
