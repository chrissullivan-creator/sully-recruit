import { useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { format, formatDistanceToNow, isPast } from 'date-fns';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { EnrollInSequenceDialog } from '@/components/candidates/EnrollInSequenceDialog';
import { TaskSidebar } from '@/components/tasks/TaskSidebar';
import { useCandidate, useNotes, useCandidateConversations, useCandidateSequenceEnrollments, useCandidateMessages } from '@/hooks/useSupabaseData';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';
import { ArrowLeft, Mail, Phone, Linkedin, Building, MapPin, Calendar, Edit, MoreHorizontal, Briefcase, MessageSquare, History, StickyNote, Play, Clock3, PauseCircle, CheckCircle2, Send, Inbox } from 'lucide-react';

const statusColors: Record<string, string> = {
  active: 'bg-success/10 text-success border-success/20',
  inactive: 'bg-muted text-muted-foreground border-border',
  placed: 'bg-info/10 text-info border-info/20',
  do_not_contact: 'bg-destructive/10 text-destructive border-destructive/20',
};

const enrollmentStatusColors: Record<string, string> = {
  active: 'bg-success/10 text-success border-success/20',
  paused: 'bg-warning/10 text-warning border-warning/20',
  completed: 'bg-info/10 text-info border-info/20',
  stopped: 'bg-muted text-muted-foreground border-border',
};

const CandidateDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { data: candidate, isLoading } = useCandidate(id);
  const { data: notes = [] } = useNotes(id, 'candidate');
  const { data: conversations = [] } = useCandidateConversations(id);
  const { data: enrollments = [] } = useCandidateSequenceEnrollments(id);
  const { data: messages = [] } = useCandidateMessages(id);
  const [enrollOpen, setEnrollOpen] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [saving, setSaving] = useState(false);

  const fullName = candidate?.full_name ?? `${candidate?.first_name ?? ''} ${candidate?.last_name ?? ''}`.trim();
  const initials = `${candidate?.first_name?.[0] ?? ''}${candidate?.last_name?.[0] ?? ''}` || 'C';

  const stats = useMemo(() => ({
    conversations: conversations.length,
    messages: messages.length,
    sequences: enrollments.length,
    activeSequences: enrollments.filter((e: any) => e.status === 'active').length,
  }), [conversations, messages, enrollments]);

  const activityItems = useMemo(() => {
    const noteItems = notes.map((note: any) => ({
      id: `note-${note.id}`,
      type: 'note',
      title: 'Note added',
      body: note.note,
      at: note.created_at,
    }));

    const messageItems = messages.map((message: any) => ({
      id: `message-${message.id}`,
      type: message.direction === 'inbound' ? 'inbound' : 'outbound',
      title: `${message.direction === 'inbound' ? 'Inbound' : 'Outbound'} ${message.channel}`,
      body: message.subject || message.body || 'No message body',
      at: message.received_at || message.sent_at || message.created_at,
    }));

    const enrollmentItems = enrollments.map((enrollment: any) => ({
      id: `enrollment-${enrollment.id}`,
      type: 'sequence',
      title: `Enrolled in ${enrollment.sequences?.name ?? 'sequence'}`,
      body: enrollment.status === 'paused' && enrollment.stopped_reason ? enrollment.stopped_reason : `Status: ${enrollment.status}`,
      at: enrollment.enrolled_at,
    }));

    return [...noteItems, ...messageItems, ...enrollmentItems]
      .sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime())
      .slice(0, 20);
  }, [notes, messages, enrollments]);

  if (isLoading) {
    return <MainLayout><div className="flex items-center justify-center h-full"><p className="text-muted-foreground">Loading...</p></div></MainLayout>;
  }

  if (!candidate) {
    return <MainLayout><div className="flex items-center justify-center h-full"><p className="text-muted-foreground">Candidate not found.</p></div></MainLayout>;
  }

  const handleSaveNote = async () => {
    if (!noteText.trim() || !id) return;
    setSaving(true);
    const { error } = await supabase.from('notes').insert({ entity_id: id, entity_type: 'candidate', note: noteText.trim() });
    if (error) {
      toast.error('Failed to save note');
    } else {
      toast.success('Note saved');
      setNoteText('');
      queryClient.invalidateQueries({ queryKey: ['notes', 'candidate', id] });
    }
    setSaving(false);
  };

  return (
    <MainLayout>
      <div className="flex items-center gap-3 px-8 py-4 border-b border-border">
        <Button variant="ghost" size="icon" onClick={() => navigate('/candidates')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-lg font-semibold text-foreground truncate">{fullName || 'Candidate'}</h1>
            <Badge className={cn('capitalize border', statusColors[candidate.status] ?? 'bg-muted text-muted-foreground border-border')}>
              {candidate.status.replaceAll('_', ' ')}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            {candidate.current_title ?? 'No title'}{candidate.current_title && candidate.current_company ? ' at ' : ''}{candidate.current_company ?? 'No company'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="gold" size="sm" onClick={() => setEnrollOpen(true)}>
            <Play className="h-3.5 w-3.5" /> Enroll in Sequence
          </Button>
          <Button variant="gold-outline" size="sm">
            <Edit className="h-3.5 w-3.5" /> Edit
          </Button>
          <Button variant="ghost" size="icon">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        <aside className="w-80 shrink-0 border-r border-border overflow-y-auto">
          <div className="p-6 space-y-6">
            <div className="flex flex-col items-center text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-accent/10 text-lg font-semibold text-accent mb-3">{initials}</div>
              <p className="text-sm text-muted-foreground">Updated {formatDistanceToNow(new Date(candidate.updated_at), { addSuffix: true })}</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Conversations</p><p className="text-xl font-semibold">{stats.conversations}</p></CardContent></Card>
              <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Messages</p><p className="text-xl font-semibold">{stats.messages}</p></CardContent></Card>
              <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Sequences</p><p className="text-xl font-semibold">{stats.sequences}</p></CardContent></Card>
              <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Live</p><p className="text-xl font-semibold">{stats.activeSequences}</p></CardContent></Card>
            </div>

            <div className="space-y-3">
              <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Contact</h3>
              <div className="space-y-2">
                {candidate.email && <div className="flex items-center gap-2 text-sm text-foreground"><Mail className="h-3.5 w-3.5 text-muted-foreground" /><a href={`mailto:${candidate.email}`} className="hover:text-accent truncate">{candidate.email}</a></div>}
                {candidate.phone && <div className="flex items-center gap-2 text-sm text-foreground"><Phone className="h-3.5 w-3.5 text-muted-foreground" /><span>{candidate.phone}</span></div>}
                {candidate.linkedin_url && <div className="flex items-center gap-2 text-sm text-foreground"><Linkedin className="h-3.5 w-3.5 text-muted-foreground" /><a href={candidate.linkedin_url} target="_blank" rel="noreferrer" className="hover:text-accent truncate">LinkedIn</a></div>}
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Current Role</h3>
              <div className="space-y-2">
                {candidate.current_title && <div className="flex items-center gap-2 text-sm text-foreground"><Briefcase className="h-3.5 w-3.5 text-muted-foreground" /><span>{candidate.current_title}</span></div>}
                {candidate.current_company && <div className="flex items-center gap-2 text-sm text-foreground"><Building className="h-3.5 w-3.5 text-muted-foreground" /><span>{candidate.current_company}</span></div>}
                {candidate.location && <div className="flex items-center gap-2 text-sm text-foreground"><MapPin className="h-3.5 w-3.5 text-muted-foreground" /><span>{candidate.location}</span></div>}
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Details</h3>
              <div className="space-y-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-2"><Calendar className="h-3.5 w-3.5" /> Added {format(new Date(candidate.created_at), 'MMM d, yyyy')}</div>
                <div className="flex items-center gap-2"><Clock3 className="h-3.5 w-3.5" /> Last touched {formatDistanceToNow(new Date(candidate.updated_at), { addSuffix: true })}</div>
              </div>
            </div>
          </div>
        </aside>

        <div className="flex-1 flex flex-col overflow-hidden">
          <Tabs defaultValue="communications" className="flex-1 flex flex-col overflow-hidden">
            <div className="px-8 pt-4">
              <TabsList className="bg-secondary">
                <TabsTrigger value="communications" className="gap-1.5"><MessageSquare className="h-3.5 w-3.5" /> Communications</TabsTrigger>
                <TabsTrigger value="sequences" className="gap-1.5"><Send className="h-3.5 w-3.5" /> Sequences</TabsTrigger>
                <TabsTrigger value="activity" className="gap-1.5"><History className="h-3.5 w-3.5" /> Activity</TabsTrigger>
                <TabsTrigger value="notes" className="gap-1.5"><StickyNote className="h-3.5 w-3.5" /> Notes</TabsTrigger>
              </TabsList>
            </div>

            <ScrollArea className="flex-1">
              <TabsContent value="communications" className="px-8 py-4 mt-0 space-y-4">
                <div className="flex items-center gap-2 mb-2 flex-wrap">
                  <Button variant="outline" size="sm"><Mail className="h-3.5 w-3.5" /> Email</Button>
                  <Button variant="outline" size="sm"><Phone className="h-3.5 w-3.5" /> Call</Button>
                  <Button variant="outline" size="sm"><Linkedin className="h-3.5 w-3.5" /> LinkedIn</Button>
                  <Button variant="outline" size="sm"><MessageSquare className="h-3.5 w-3.5" /> SMS</Button>
                </div>

                {messages.length === 0 ? (
                  <Card><CardContent className="p-8 text-sm text-muted-foreground">No communications yet. An empty relationship dashboard, the internet's most honest feature.</CardContent></Card>
                ) : (
                  messages.map((message: any) => (
                    <Card key={message.id}>
                      <CardContent className="p-4 space-y-2">
                        <div className="flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2 flex-wrap">
                            <Badge variant="secondary" className="capitalize">{message.channel}</Badge>
                            <Badge variant="outline" className="capitalize">{message.direction}</Badge>
                            {message.subject && <span className="text-sm font-medium text-foreground">{message.subject}</span>}
                          </div>
                          <span className="text-xs text-muted-foreground">{format(new Date(message.received_at || message.sent_at || message.created_at), 'MMM d, yyyy h:mm a')}</span>
                        </div>
                        <p className="text-sm text-muted-foreground whitespace-pre-wrap">{message.body || 'No message body captured.'}</p>
                        <div className="text-xs text-muted-foreground">
                          {(message.direction === 'inbound' ? message.sender_address : message.recipient_address) || 'Address unavailable'}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>

              <TabsContent value="sequences" className="px-8 py-4 mt-0">
                {enrollments.length === 0 ? (
                  <Card><CardContent className="p-8 text-sm text-muted-foreground">This candidate is not enrolled in any sequences yet.</CardContent></Card>
                ) : (
                  <div className="space-y-4">
                    {enrollments.map((enrollment: any) => {
                      const seq = enrollment.sequences;
                      const isOverdue = enrollment.status === 'active' && enrollment.next_step_at && isPast(new Date(enrollment.next_step_at));
                      return (
                        <Card key={enrollment.id}>
                          <CardContent className="p-5 space-y-3">
                            <div className="flex items-start justify-between gap-3">
                              <div>
                                <div className="flex items-center gap-2 flex-wrap">
                                  <p className="font-medium text-foreground">{seq?.name ?? 'Sequence'}</p>
                                  <Badge className={cn('capitalize border', enrollmentStatusColors[enrollment.status] ?? 'bg-muted text-muted-foreground border-border')}>{enrollment.status}</Badge>
                                  {seq?.stop_on_reply && <Badge variant="outline">Stops on reply</Badge>}
                                  {isOverdue && <Badge variant="destructive">Step overdue</Badge>}
                                </div>
                                <p className="text-sm text-muted-foreground mt-1">{seq?.description || `${seq?.channel ?? 'multi-channel'} outreach`}</p>
                              </div>
                              <div className="text-xs text-muted-foreground text-right">
                                <div>Enrolled {formatDistanceToNow(new Date(enrollment.enrolled_at), { addSuffix: true })}</div>
                                {enrollment.next_step_at && <div>Next step {format(new Date(enrollment.next_step_at), 'MMM d, yyyy h:mm a')}</div>}
                              </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                              <div className="rounded-md border border-border p-3"><p className="text-xs text-muted-foreground">Channel</p><p className="text-foreground capitalize">{seq?.channel ?? '-'}</p></div>
                              <div className="rounded-md border border-border p-3"><p className="text-xs text-muted-foreground">Current Step</p><p className="text-foreground">{enrollment.current_step_order ?? '-'}</p></div>
                              <div className="rounded-md border border-border p-3"><p className="text-xs text-muted-foreground">Reason</p><p className="text-foreground">{enrollment.stopped_reason || 'Still moving'}</p></div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="activity" className="px-8 py-4 mt-0">
                {activityItems.length === 0 ? (
                  <Card><CardContent className="p-8 text-sm text-muted-foreground">No activity yet.</CardContent></Card>
                ) : (
                  <div className="space-y-3">
                    {activityItems.map((item) => (
                      <Card key={item.id}>
                        <CardContent className="p-4 flex items-start gap-3">
                          <div className="mt-0.5 flex h-8 w-8 items-center justify-center rounded-full bg-secondary text-muted-foreground">
                            {item.type === 'note' ? <StickyNote className="h-4 w-4" /> : item.type === 'sequence' ? <Send className="h-4 w-4" /> : item.type === 'inbound' ? <Inbox className="h-4 w-4" /> : <Send className="h-4 w-4" />}
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-3">
                              <p className="text-sm font-medium text-foreground">{item.title}</p>
                              <span className="text-xs text-muted-foreground">{format(new Date(item.at), 'MMM d, yyyy h:mm a')}</span>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1 whitespace-pre-wrap">{item.body}</p>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="notes" className="px-8 py-4 mt-0">
                <div className="space-y-4">
                  <Card>
                    <CardHeader><CardTitle className="text-sm">Add Note</CardTitle></CardHeader>
                    <CardContent className="space-y-3">
                      <Textarea placeholder="Add a note..." value={noteText} onChange={(e) => setNoteText(e.target.value)} className="min-h-28" />
                      <Button variant="gold" size="sm" onClick={handleSaveNote} disabled={saving || !noteText.trim()}>Save Note</Button>
                    </CardContent>
                  </Card>
                  {notes.length > 0 ? (
                    <div className="space-y-3">
                      {notes.map((n: any) => (
                        <Card key={n.id}><CardContent className="p-4"><p className="text-sm text-foreground whitespace-pre-wrap">{n.note}</p><p className="text-xs text-muted-foreground mt-2">{format(new Date(n.created_at), 'MMM d, yyyy h:mm a')}</p></CardContent></Card>
                      ))}
                    </div>
                  ) : (
                    <Card><CardContent className="p-8 text-sm text-muted-foreground">No notes yet.</CardContent></Card>
                  )}
                </div>
              </TabsContent>
            </ScrollArea>
          </Tabs>
        </div>

        {id && <div className="w-80 shrink-0 border-l border-border p-4 overflow-y-auto"><TaskSidebar entityType="candidate" entityId={id} /></div>}
      </div>

      <EnrollInSequenceDialog open={enrollOpen} onOpenChange={setEnrollOpen} candidateIds={id ? [id] : []} candidateNames={[fullName || 'Candidate']} />
    </MainLayout>
  );
};

export default CandidateDetail;
